from pathlib import Path
import json,copy
R=Path.cwd();p=json.load(open('.aiwg/testing/conformance.yaml'));before=copy.deepcopy(p['spec']['lanes']);review=json.load(open('.aiwg/testing/review-sut-scope-08.json'));s=p['spec'];addedSource=[];addedConfig=[]
for pattern in review['minimalSourceAdditions']:
 if pattern not in s['source']['include']:s['source']['include'].append(pattern);addedSource.append(pattern)
bound={f['path'] for f in json.load(open('.aiwg/testing/inventory-08.json'))['spec']['files']}
sourceExplicit={r['path'] for r in review['confirmedMissingBindings'] if r['recommendedBinding']=='source'}
def config(path):
 path=Path(path)
 if not path.is_file():return
 # Link target content is bound without asking inventory to follow a symlink.
 name=str(path.resolve().relative_to(R)) if path.is_symlink() else str(path)
 if name in bound or name in sourceExplicit or name in s['configFiles']:return
 if name.endswith(('.js','.mjs','.cjs','.jsx','.css')):return
 if Path(name).stat().st_size>1048576:raise RuntimeError('review large dependency: '+name)
 s['configFiles'].append(name);addedConfig.append(name)
for name in review['minimalExplicitConfigAdditions']:config(name)
# Entire exact input sets consumed by the already-required recipe builds, not arbitrary products.
registry=json.load(open('apps/publisher/examples/recipes.tenants.json'))
roots={Path('apps/publisher')/t['source']['path'] for t in registry['tenants'] if t.get('enabled',True) and t.get('source',{}).get('type')=='local'}
roots.update(Path('apps/publisher/tenants')/x for x in ['tenant-alpha','tenant-beta','pagenary'])
for root in sorted(roots):
 for file in sorted(root.rglob('*')):
  if file.is_file() and file.suffix.lower() in ['.json','.md','.html','.tex','.bib','.vtt','.txt','.svg']:
   if str(file).startswith('apps/publisher/examples/syntax-gallery/content/') and file.suffix in ['.md','.tex']:continue
   config(file)
# Direct config-theme scanner traverses every example config.json.
for file in sorted(Path('apps/publisher/examples').rglob('config.json')):config(file)
# Converter qualification fixtures: omit descriptive README, bind actual source/includes/assets.
for file in sorted(Path('apps/publisher/__tests__/fixtures/latex-pages').rglob('*')):
 if file.is_file() and file.name!='README.md':config(file)
assert before==s['lanes']
proposal={'purpose':'Bind actual reviewed production SUTs and consumed test inputs omitted by inventory08; all24lane andcontrolrecipes unchanged. Apply only after active collectors finish, then regenerate evidence.','edits':[{'path':'.aiwg/testing/conformance.yaml','content':json.dumps(p,indent=2)+'\n'}]}
Path('.aiwg/testing/edits-protocol-source-09.json').write_text(json.dumps(proposal,indent=2)+'\n')
Path('.aiwg/testing/protocol-source-09-report.json').write_text(json.dumps({'sourceAdditions':addedSource,'exactConfigAdditions':addedConfig,'lanesAndControlsByteEquivalentAsObjects':True,'configInputScope':'Files read by required recipe/tenant builds, example config scanner, schema tests, direct document tests and external LaTeX fixtures. Exact paths; no unrelated script expansion.','limitations':['Symlink target bytes are bound; link mapping metadata itself is not attested by this inventory.','Large/unasserted binary media inputs are not added in this minimal text/config binding repair.'],'requiresNewEvidence':True,'applied':False},indent=2)+'\n')
print('source patterns',len(addedSource),'exact config inputs',len(addedConfig))
