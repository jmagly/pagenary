from pathlib import Path
import json,hashlib,difflib,copy,subprocess
R=Path.cwd()
def h(s): return hashlib.sha256(s.encode()).hexdigest()
def out(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def read(p):return Path(p).read_text()
protocol=json.loads(json.load(open('.aiwg/testing/edits-protocol-05.json'))['edits'][0]['content'])
P=protocol['spec']; additions=['apps/authoring-contract/**/*.cjs','apps/publisher/examples/syntax-gallery/content/**/*.md','apps/publisher/src/**/*.css','apps/publisher/site/**/*.css','scripts/testing/lib/**/*.mjs']
for p in additions:
 if p not in P['source']['include']:P['source']['include'].append(p)
for p in ['scripts/testing/atspi-runner.py','scripts/testing/setup-browser.mjs','scripts/testing/fresh-fixture-runner.mjs']:
 if p not in P['configFiles']:P['configFiles'].append(p)
# Fresh fixture preparation stays runner-bound; imports resolve live source.
fixture='''import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { runManagedProcess } from '../../apps/publisher/scripts/lib/process-lifecycle.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const publisher = path.join(root, 'apps/publisher');
const args = process.argv.slice(2);
if (args[0] !== '--fixture' || !['syntax-gallery', 'seo'].includes(args[1])) throw new Error('Explicit supported fixture required');
async function run(command, argv, cwd) {
  const result = await runManagedProcess(command, argv, { cwd }, 1_140_000);
  process.stdout.write(result.stdout); process.stderr.write(result.stderr);
  if (result.code !== 0 || result.signal) throw new Error(`Fixture action failed (${result.code ?? result.signal})`);
}
if (args[1] === 'syntax-gallery') {
  await run(process.execPath, ['scripts/build-tenants.js', '--registry', 'examples/recipes.tenants.json', 'syntax-gallery'], publisher);
} else {
  await run(process.execPath, ['scripts/build.js'], publisher);
}
if (args.length > 2) {
  if (args[2] !== '--' || !args[3]) throw new Error('Fixture command requires explicit argv after --');
  await run(args[3], args.slice(4), publisher);
}
'''
edits=[{'path':'scripts/testing/fresh-fixture-runner.mjs','content':fixture}]
s=read('scripts/testing/atspi-runner.py');needle="    if not (root / 'apps/publisher/dist/syntax-gallery/index.html').is_file():"
assert s.count(needle)==1;s=s.replace(needle,"    if not args.session:\n        subprocess.run(['node', str(root / 'scripts/testing/fresh-fixture-runner.mjs'),\n                        '--fixture', 'syntax-gallery'], cwd=root, check=True, timeout=1150)\n"+needle)
edits.append({'path':'scripts/testing/atspi-runner.py','content':s})
s=read('apps/publisher/scripts/smoke-browser.mjs');s=s.replace("  if (fs.existsSync(shell)) return;\n",'').replace("console.log(`• dist/${TENANT} missing — building tenant…`);","console.log(`• Building fresh dist/${TENANT} from current source…`);")
needle="async function loadPlaywright() {\n  try {";assert needle in s;s=s.replace(needle,"async function loadPlaywright() {\n  if (process.env.PLAYWRIGHT_MODULE) return import(process.env.PLAYWRIGHT_MODULE);\n  try {")
edits.append({'path':'apps/publisher/scripts/smoke-browser.mjs','content':s})
s=read('apps/publisher/scripts/smoke-accessibility.mjs');needle="  if (fs.existsSync(shell) && fs.existsSync(blog) && fs.existsSync(effects)) return;\n";assert needle in s;s=s.replace(needle,'');edits.append({'path':'apps/publisher/scripts/smoke-accessibility.mjs','content':s})
out('.aiwg/testing/edits-fixture-orchestration-02.json',{'purpose':'Fresh baseline/mutant/restored browser and AT-SPI/SEO builds; explicit pinned browser module resolution.','edits':edits})
lanes={l['id']:l for l in P['lanes']}
styleid='apps-publisher-scripts-smoke-styles-mjs';stylefile='apps/publisher/scripts/smoke-styles.mjs'
def wrapper(file,cwd,argv,mode='execution'):
 return {'argv':['node','scripts/testing/harness-runner.mjs','--mode',mode,'--file',file,'--cwd',cwd,'--timeout','1190000','--',*argv],'timeoutMs':1200000}
style={'id':styleid,'runner':'custom','include':[stylefile],'exclude':[],'command':wrapper(stylefile,'apps/publisher',['node','scripts/smoke-styles.mjs']),'result':{'format':'canonical'},'required':True,'negativeControls':[],'versionCommand':['node','--version']}
style['discovery']={'command':wrapper(stylefile,'apps/publisher',['node','scripts/smoke-styles.mjs'],'discovery'),'result':{'format':'canonical'}};style['discovery']['command']['timeoutMs']=30000
P['lanes'].append(style);lanes[styleid]=style
module='/tmp/pagenary-playwright/node_modules/playwright/index.mjs';browsers='/home/roctinam/.codex/roles-runtime/full/.cache/ms-playwright'
for lane in P['lanes']:
 if lane['runner']=='custom':
  env=lane['command'].setdefault('env',{});env.update(SMOKE_REQUIRE='1',PLAYWRIGHT_MODULE=module,PAGENARY_PLAYWRIGHT_MODULE=module,PLAYWRIGHT_BROWSERS_PATH=browsers,CHROME_PATH=browsers+'/chromium-1193/chrome-linux/chrome')
style['command']['env']['PAGENARY_STYLE_BROWSERS']='chromium,firefox,webkit'
atspi=lanes['apps-publisher-scripts-smoke-rich-content-atspi-py'];checker='apps/publisher/scripts/smoke-rich-content-atspi.py'
a=['/usr/bin/python3','scripts/testing/atspi-runner.py','--checker',checker,'--firefox',browsers+'/firefox-1490/firefox/firefox']
for mode in ['execution','discovery']:
 cmd=wrapper(checker,'.',a,mode)
 if mode=='execution':cmd['env']=atspi['command']['env'];atspi['command']=cmd
 else:cmd['timeoutMs']=30000;atspi['discovery']={'command':cmd,'result':{'format':'canonical'}}
external=lanes['ci-rich-content-qualify-mjs'];recipe=json.load(open('.aiwg/testing/recipe-external-renderers-01.json'))['argv']
for mode in ['execution','discovery']:
 cmd=wrapper('ci/rich-content/qualify.mjs','.',recipe,mode)
 if mode=='execution':cmd['env']=external['command']['env'];external['command']=cmd
 else:cmd['timeoutMs']=30000;external['discovery']={'command':cmd,'result':{'format':'canonical'}}
seo=lanes['publisher-seo'];seoargv=['node','../../scripts/testing/fresh-fixture-runner.mjs','--fixture','seo','--','node','scripts/seo-smoke.js']
for mode in ['execution','discovery']:
 cmd=wrapper('apps/publisher/scripts/seo-smoke.js','apps/publisher',seoargv,mode)
 if mode=='execution':cmd['env']=seo['command']['env'];seo['command']=cmd
 else:cmd['timeoutMs']=30000;seo['discovery']={'command':cmd,'result':{'format':'canonical'}}
# Hash-bound mutations, preserving later harmless source edits.
controls=json.load(open('.aiwg/testing/controls-harnesses-proposals-01.json'))['controls']
base03={e['path']:e['content'] for e in json.load(open('.aiwg/testing/edits-publisher-03.json'))['edits']}
reports=[];plans=[]
def plan_control(lane,ident,es,description,ids):
 ep=f'.aiwg/testing/edits-control-{ident}-06.json';pp=f'.aiwg/testing/plan-control-{ident}-06.json'
 out(ep,{'purpose':'Source-only negative control: '+description,'edits':es})
 plans.append((ep,pp))
 l=lanes[lane];l['negativeControls']=[{'id':ident,'description':description,'changePlan':pp,'command':copy.deepcopy(l['command']),'result':copy.deepcopy(l['result']),'testIds':ids}]
 reports.append({'lane':lane,'control':ident,'edits':ep,'plan':pp,'sources':[{'path':e['path'],'baselineSha256':h(read(e['path'])),'mutantSha256':h(e['content'])} for e in es],'expected':description})
for i,c in enumerate(controls,1):
 es=[]
 for e in c['sourceEdits']:
  current=read(e['path']);mutant=e['content']
  if h(current)!=e['baseSha256']:
   original=base03[e['path']];assert h(original)==e['baseSha256']
   # Only localized source delta is transplanted; changed base snippets must be unique.
   a=original.splitlines(True);b=mutant.splitlines(True);patched=current
   for tag,i1,i2,j1,j2 in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes():
    if tag=='equal':continue
    old=''.join(a[i1:i2]);new=''.join(b[j1:j2]);assert old and patched.count(old)==1,(c['lane'],old)
    patched=patched.replace(old,new,1)
   mutant=patched
  es.append({'path':e['path'],'content':mutant})
 l=lanes[c['lane']];file=l['include'][0];identity=json.dumps(['harness',file,'standalone harness'],separators=(',',':'))
 plan_control(c['lane'],f'harness-{i:02d}',es,c['expectedClaim'],[identity])
for c in json.load(open('.aiwg/testing/controls-publisher-tooling-01.json'))['controls']:
 assert h(read(c['sourcePath']))==c['baselineSha256'],c['sourcePath']
 es=json.load(open(c['editProposal']))['edits'];plan_control(c['lane'],c['id'],es,'; '.join(x['assertion'] for x in c['expectedFailures']),[x['id'] for x in c['expectedFailures']])
css=read('apps/publisher/src/styles.css');needle='  .page-toc--right {\n    position: static;';assert css.count(needle)==1
plan_control(styleid,'style-mobile-toc-position',[{'path':'apps/publisher/src/styles.css','content':css.replace(needle,'  .page-toc--right {\n    position: fixed;',1)}],'At mobile viewport computed .page-toc--right position must be static, not fixed.',[json.dumps(['harness',stylefile,'standalone harness'],separators=(',',':'))])
# Existing React plan must still bind the current source.
reactplan=json.load(open(lanes['react']['negativeControls'][0]['changePlan']))
for e in reactplan['spec']['changes']:
 assert h(read(e['path']))==e['before']['hash'],e['path']
out('.aiwg/testing/edits-protocol-06.json',{'purpose':'Whole-scope required lanes with fresh fixtures, pinned runtime prerequisites and exactly matching lane/control recipes.','edits':[{'path':'.aiwg/testing/conformance.yaml','content':json.dumps(protocol,indent=2)+'\n'}]})
out('.aiwg/testing/protocol-06-controls-report.json',{'protocolProposal':'.aiwg/testing/edits-protocol-06.json','fixtureProposal':'.aiwg/testing/edits-fixture-orchestration-02.json','controls':reports,'planCommands':plans,'limitations':['Control case IDs predicted from qualified canonical adapter formula; final discovery/baseline must confirm each ID.','No source mutation or control execution performed.','Public plans bind current source; concurrent source changes require regeneration.','External renderer bind uses authoritative worktree absolute path, as exact approved recipe.'],'contractChecks':{'allRequired':all(l['required'] for l in P['lanes']),'allLanesHaveControls':all(l['negativeControls'] for l in P['lanes']),'exactControlRecipes':all(c['command']==l['command'] and c['result']==l['result'] for l in P['lanes'] for c in l['negativeControls'])}})
print('Prepared protocol06, fixture proposal,23 control edit proposals; no source changes.')
