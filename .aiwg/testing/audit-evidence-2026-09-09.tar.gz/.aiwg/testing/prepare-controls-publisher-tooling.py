from pathlib import Path
import json,hashlib
root=Path('.')
def digest(s):return hashlib.sha256(s.encode()).hexdigest()
def emit(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')
# Correct setup failure ordering in the not-yet-applied lazy allocation proposal.
p=Path('.aiwg/testing/edits-publisher-04.json');data=json.loads(p.read_text());s=data['edits'][0]['content']
old="""    await Promise.all(['tenant-alpha', 'tenant-beta'].map((id) => fsp.cp(
      path.join(packageRoot, 'tenants', id), path.join(root, 'tenants', id), { recursive: true }
    )));"""
new="""    for (const id of ['tenant-alpha', 'tenant-beta']) {
      await fsp.cp(path.join(packageRoot, 'tenants', id), path.join(root, 'tenants', id), { recursive: true });
    }"""
assert old in s;s=s.replace(old,new);data['edits'][0]['content']=s;emit(str(p),data)
# Preserve runner configuration binding while sharing its actual outcome semantics.
lib='scripts/testing/lib/harness-outcome.mjs'
content='''/** Classify a completed standalone action without converting environment failures into evidence. */
export function classifyHarnessOutcome(state) {
  const errors = [];
  const fail = (code, message) => errors.push({ code, message });
  if (state.interrupted) fail('INTERRUPTED', 'Harness runner was interrupted');
  if (state.spawnError) fail('SPAWN_ERROR', state.spawnError.message);
  if (state.timedOut) fail('TIMEOUT', 'Harness exceeded its bounded runtime');
  if (state.signal) fail('SIGNAL', `Harness terminated by ${state.signal}`);
  // Prerequisite failures and explicit skips never qualify as mutation kills.
  if (/ERR_MODULE_NOT_FOUND|Cannot find module|No module named|Playwright is required|Executable doesn't exist|dist\\/ not found/.test(state.tail)) fail('MISSING_PREREQUISITE', 'Harness stopped at an unavailable prerequisite; see raw diagnostics');
  if (/^.*(?:skipping browser|SKIP:|SKIPPED:).*$/im.test(state.tail)) fail('SKIPPED_HARNESS', 'Harness reported skipped work');
  const status = state.code === 0 && !errors.length ? 'passed' : 'failed';
  return { errors, status, complete: errors.length === 0, exitCode: status === 'passed' ? 0 : 1 };
}
'''
runnerpath='scripts/testing/harness-runner.mjs';before=Path(runnerpath).read_text();runner=before.replace("import { pathToFileURL } from 'node:url';", "import { pathToFileURL } from 'node:url';\nimport { classifyHarnessOutcome } from './lib/harness-outcome.mjs';")
a=runner.index("    if (state.interrupted) fail(");b=runner.index("  } catch (error)",a)
runner=runner[:a]+'''    const outcome = classifyHarnessOutcome(state);
    out.errors.push(...outcome.errors);
    item.status = outcome.status;
    out.files[0].status = item.status; out.summary[item.status] = 1;
    out.complete = outcome.complete;
    exitCode = outcome.exitCode;
'''+runner[b:]
testpath='scripts/testing/runner-qualification.test.mjs';tests=Path(testpath).read_text();tests=tests.replace("import { registeredNodeTests } from './node-discovery.mjs';", "import { registeredNodeTests } from './node-discovery.mjs';\nimport { classifyHarnessOutcome } from './lib/harness-outcome.mjs';")
tests+='''
test('completed harness outcomes preserve exit failures and distinguish incomplete evidence', () => {
  const normal = { code: 0, signal: null, tail: '', timedOut: false, interrupted: false };
  assert.deepEqual(classifyHarnessOutcome(normal), { errors: [], status: 'passed', complete: true, exitCode: 0 });
  assert.deepEqual(classifyHarnessOutcome({ ...normal, code: 1 }), { errors: [], status: 'failed', complete: true, exitCode: 1 });
  for (const [override, code] of [
    [{ interrupted: true }, 'INTERRUPTED'],
    [{ spawnError: new Error('spawn failed') }, 'SPAWN_ERROR'],
    [{ timedOut: true }, 'TIMEOUT'],
    [{ signal: 'SIGTERM' }, 'SIGNAL'],
    [{ tail: 'ERR_MODULE_NOT_FOUND' }, 'MISSING_PREREQUISITE'],
    [{ tail: 'SKIP: unavailable' }, 'SKIPPED_HARNESS']
  ]) {
    const result = classifyHarnessOutcome({ ...normal, ...override });
    assert.equal(result.status, 'failed');
    assert.equal(result.complete, false);
    assert.equal(result.exitCode, 1);
    assert.deepEqual(result.errors.map(error => error.code), [code]);
  }
});
'''
emit('.aiwg/testing/edits-tooling-outcome-01.json',{'purpose':'Extract the production harness outcome classifier while preserving configured runner bindings and complete failure semantics.','edits':[{'path':lib,'content':content},{'path':runnerpath,'content':runner},{'path':testpath,'content':tests}]})
controls=[]
def control(lane,ident,path,base,old,new,names,assertions,command,result):
 assert base.count(old)==1,(path,old)
 mutant=base.replace(old,new)
 artifact=f'.aiwg/testing/edits-control-{ident}-01.json'
 emit(artifact,{'purpose':f'Source-only negative control: {ident}', 'edits':[{'path':path,'content':mutant}]})
 controls.append({'lane':lane,'id':ident,'editProposal':artifact,'changePlan':f'.aiwg/testing/plan-control-{ident}-01.json','sourcePath':path,'baselineSha256':digest(base),'mutantSha256':digest(mutant),'mutation':{'before':old,'after':new},'expectedFailures':[{'file':f,'name':n,'id':json.dumps([lane,f,n],separators=(',',':')),'assertion':a} for (f,n),a in zip(names,assertions)],'command':command,'result':result,'sourceOnly':True,'executed':False})
f='apps/publisher/__tests__/scripts/rich-content-core.test.js'
control('publisher','strict-policy-disabled','apps/publisher/scripts/lib/rich-content-adapters.js',Path('apps/publisher/scripts/lib/rich-content-adapters.js').read_text(),"if (policy === 'strict' && failure) {","if (false && policy === 'strict' && failure) {",[(f,'rich-content adapter registry invalid nodes honor strict policy before rendering'),(f,'rich-content adapter registry strict policy rejects cached error diagnostics from a permissive render'),(f,'rich-content adapter registry strict policy rejects missing adapters and error-bearing render results')],['Expected rejection with MOCK_BAD diagnostics; mutant resolves a fallback.','Expected rejection with CACHED_ERROR; mutant resolves the cached payload.','Expected rejection with RTC_RENDERER_UNAVAILABLE; mutant resolves the missing-adapter fallback. The later partial-result assertion is not reached in this mutant.'],{'argv':['node','--experimental-vm-modules','node_modules/jest/bin/jest.js','--config','apps/publisher/jest.config.js','--runInBand','--runTestsByPath',f,'--json','--outputFile=.aiwg/testing/conformance/raw/{runId}/publisher-strict-control.json'],'timeoutMs':60000},{'format':'jest','path':'.aiwg/testing/conformance/raw/{runId}/publisher-strict-control.json'})
f=testpath
names=['assertion failures remain failures, while missing prerequisites remain incomplete','completed harness outcomes preserve exit failures and distinguish incomplete evidence']
control('tooling','harness-exit-ignored',lib,content,"state.code === 0 && !errors.length ? 'passed' : 'failed'","!errors.length ? 'passed' : 'failed'",[(f,json.dumps([n],separators=(',',':'))) for n in names],['Expected failed.exitCode=1 after actual assertion failure; mutant reports 0.','Expected complete ordinary exit1 outcome {status:failed,exitCode:1}; mutant reports passed and0.'],{'argv':['node','--test','--test-reporter=./scripts/testing/node-reporter.mjs','scripts/testing/*.test.mjs'],'timeoutMs':60000,'env':{'PAGENARY_TEST_LANE':'tooling'}},{'format':'canonical'})
emit('.aiwg/testing/controls-publisher-tooling-01.json',{'purpose':'Reviewable source-only controls; parent must create guarded plans after integrating current pending edits.','protocolPath':'.aiwg/testing/conformance.yaml','protocolSha256AtPreparation':hashlib.sha256(Path('.aiwg/testing/conformance.yaml').read_bytes()).hexdigest(),'prerequisites':['Apply edits-tooling-outcome-01.json and add scripts/testing/lib/**/*.mjs to protocol source.include.','Keep scripts/testing/harness-runner.mjs and node-reporter.mjs in configFiles.','Generate control plans from final baseline matching baselineSha256; do not apply control edits as regular fixes.','Run final baseline discovery/execution before controls; attach actual registered testIds and control receipts.'],'controls':controls,'lazyHelperReview':{'proposal':'.aiwg/testing/edits-publisher-04.json','verdict':'source-reviewed','findingsResolved':['Import does not allocate a directory; zero-match registration does not leak.','Exclusive mkdir and ownsRoot guard prevent cleanup of unowned roots.','Sequential copy prevents asynchronous sibling setup writes outliving setup rejection and cleanup.'],'limitations':['Syntax/runtime verification of these pending replacements remains for parent.']}})
print('Prepared tooling extraction, two control edits/manifest, and updated lazy helper artifact; no source edits or control execution.')
