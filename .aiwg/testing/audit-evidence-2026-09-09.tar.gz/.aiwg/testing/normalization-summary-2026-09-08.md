# Testing conformance audit and normalization — 2026-09-08

The audit and reviewed repair batch are complete. The full declared regime remains **nonconformant**: the final machine assessment contains 40 passed, 15 failed and 96 unknown gates. Passing execution is not a claim that every oracle, harness or registration path is qualified.

Work is in `/tmp/pagenary-runtime-delivery-184-186`, based on canonical source commit `e4f4e6fa3ea7e31bcf0faa35196e3d22788f5232`. The original `/home/roctinam/dev/pagenary` contains an older HEAD and preexisting edits; its local AIWG deployment was refreshed independently. Testing changes are applied and uncommitted in the isolated worktree. No remote delivery or CI success is claimed.

## Scope

AIWG 2026.9.6 / testing-quality 2.0.0 inventoried **163 source files, 79 test files and 15 configuration files**. No statement about statement/branch coverage is made; no coverage threshold was invented.

The initial seeded sample (`pagenary-2026-09-08`) reviewed 20 of 48 publisher files and a census of 10 React plus 20 standalone harness files. Follow-up review added the LaTeX parameterized-test file and new reporter test file. **52 full files reviewed; 27 publisher files remain unreviewed.** Final source-review verdicts: 33 passed, 15 failed, 4 unknown. Review records mark 19 findings resolved and retain 18 open findings; browser repairs are not treated as executed browser proof.

## Applied normalization

- Unified `npm test` covers publisher, React, extension and reporter tests; a new canonical Gitea workflow runs it. Separate checks/browser commands and their boundaries are documented in [TESTING.md](../../TESTING.md).
- Replaced self-referential theme assertions with independently calculated contrast and known fixtures; separated forbidden-import and WASM checks; asserted the reconciliation deletion marker and stable replay timestamp.
- Required expected graph nodes, manifest membership before ordering, an actual HTML body before negative checks, independent tenant identities, and nonempty hashed rebuild artifacts.
- Asserted sanitizer behavior on emitted PlantUML SVG bytes and retained useful content. Registered temporary-cache and second-output-directory cleanup before assertions.
- Rejected empty runtime asset lists/entries, syntax inventories, traceability populations and browser selections. Captured image-exclusion observations before cleanup removes the markers.
- Corrected overbroad test names, gave parameterized Jest cases unique identities, and added a Node reporter retaining actual file attribution, failures/skips and incomplete-report diagnostics.

Changes were applied through guarded AIWG plans and receipts (`plan-normalize-01`, `apply-normalize-01`, `plan-reporting-02`, `apply-reporting-02`, and documentation plan/receipt). Original audit artifacts remain intact.

## Verification

| Evidence | Result |
| --- | --- |
| Publisher execution, 48 suites | **698 passed**, no skips/failures, all cases normalized without duplicate IDs |
| React execution, 10 files | **49 passed**, all cases attributed to files |
| Reporter qualification | **6 passed**, including malformed, duplicate, missing-file and truncated-event cases |
| Extension smoke and activation | Passed native workspace command; mocked host boundary retained |
| Syntax and traceability | 56/56 features and 56/56 requirements passed |
| Accessibility/media/narration/reading standalone checks | Passed; accessibility reports two existing example color warnings |
| Graph bundle audit | Passed; nonempty JS entry 221,213 bytes |
| Empty-input controls in copied fixture roots | All three rejected their intended invalid population/selection; positive syntax/traceability passed before and after restoration |
| Source-changing contrast control | **Killed**: selected baseline cases passed, failed with constant-high contrast, then passed after restoration; all 49 React cases passed after restoration |
| Browser accessibility smoke | **Blocked at missing Playwright**, exit 1 under `SMOKE_REQUIRE=1`; no browser behavior success claimed |
| Whitespace check | `git diff --check` passed |

The source mutation was restored and the production theme file matches the original git source. Native checks outside qualified adapters are supporting validation, not silently added to the machine conformance receipts. Node reporter target integration was verified on Node 24.12.0; CI Node 20 execution remains unverified remotely.

## Remaining work

1. Repair remaining reviewed oracle/process issues: credential test currently blesses truncation after a password colon, readiness can accept an unrelated server, subprocess cleanup can hang/short-circuit, some renderer assertions omit retained output, and several validators only observe aggregate counts or completion messages.
2. Qualify standalone adapters and their commands. Current protocol includes explicit inventory placeholders that do not emit canonical results; AT-SPI needs a declared `math`/`diagrams` mode and a process-scoped accessibility oracle. Do not blindly collect all placeholder lanes.
3. Provide Playwright/browser engines and renderer/desktop prerequisites, then execute the changed browser checks. Missing Docs Map output must be distinguished from an explicitly disabled configuration.
4. Finish the 27 unreviewed publisher files and additional source-bound controls. The one killed contrast mutation proves only its named oracle.
5. Implement/qualify registration adapters. Jest listTests produces 48 file paths, but AIWG's Jest parser expects a reporter object; it reports malformed/empty discovery. React has no separate discovery receipt. File lists and executed cases are not substituted for registered cases.

No assertions, skips, thresholds or required lanes were relaxed to produce a green result.

## Evidence

- [Initial machine report](report-01.md) and [final machine report](report-02.md)
- [Final assessment](assessment-02.json), [inventory](inventory-04.json), [initial seeded sample](sample-03.json)
- [Publisher execution](execution-publisher-02.json), [React execution](execution-react-02.json), [reporter execution](execution-tooling-01.json)
- [Contrast control and restoration](controls-react-01.json), [copied-harness validation](validation-harnesses-01.json)
- [Publisher reviews](reviews-publisher-02.json), [React/tooling reviews](reviews-react-02.json), [harness reviews](reviews-harnesses-02.json)

Machine receipts preserve raw paths, source hashes, runner versions and command exits. They are tied to this checkout and must not be relabeled for another source revision. See the original workspace's `.aiwg/reports/aiwg-health-2026-09-08.md` for deployment health and remaining advisories.
