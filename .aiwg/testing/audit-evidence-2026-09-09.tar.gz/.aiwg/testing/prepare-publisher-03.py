import pathlib,json,re,subprocess,difflib
root=pathlib.Path.cwd(); edits={}
def read(p):return (root/p).read_text()
def put(p,s):edits[p]=s
def replace(s,a,b,n=1):
 assert s.count(a)==n,(a[:100],s.count(a),n)
 return s.replace(a,b)
put('apps/publisher/scripts/lib/process-lifecycle.js',r'''import { spawn } from 'node:child_process';

// Register close/error tracking immediately, before any readiness or cleanup wait.
export function startManagedProcess(command, args, options = {}) {
  const child = spawn(command, args, {
    ...options,
    detached: process.platform !== 'win32',
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let stdout = '';
  let stderr = '';
  let spawnError;
  let closed = false;
  let stopped;
  child.stdout.on('data', (data) => { stdout = (stdout + data).slice(-8 * 1024 * 1024); });
  child.stderr.on('data', (data) => { stderr = (stderr + data).slice(-8 * 1024 * 1024); });
  child.on('error', (error) => { spawnError = error; });
  const completion = new Promise((resolve) => child.once('close', (code, signal) => {
    closed = true;
    resolve({ code, signal, stdout, stderr, error: spawnError });
  }));
  function signalTree(signal) {
    try {
      if (process.platform !== 'win32' && child.pid) process.kill(-child.pid, signal);
      else child.kill(signal);
    } catch (error) {
      if (error.code !== 'ESRCH') throw error;
    }
  }
  async function wait(timeoutMs) {
    let timer;
    try {
      return await Promise.race([
        completion,
        new Promise((resolve) => { timer = setTimeout(() => resolve(null), timeoutMs); })
      ]);
    } finally { clearTimeout(timer); }
  }
  function stop() {
    if (stopped) return stopped;
    stopped = (async () => {
      if (closed) return completion;
      signalTree('SIGTERM');
      let result = await wait(1000);
      if (!result) {
        signalTree('SIGKILL');
        result = await wait(3000);
      }
      if (!result) throw new Error(`Child ${child.pid} did not close after SIGKILL`);
      return result;
    })();
    return stopped;
  }
  async function waitForOutput(pattern, timeoutMs = 10000) {
    let timer;
    let onData;
    try {
      return await Promise.race([
        new Promise((resolve) => {
          onData = () => {
            const match = stdout.match(pattern);
            if (match) resolve(match);
          };
          child.stdout.on('data', onData);
          onData();
        }),
        completion.then((result) => {
          throw new Error(`Child exited before readiness (${result.code ?? result.signal}): ${result.error?.message || result.stderr}`);
        }),
        new Promise((_, reject) => {
          timer = setTimeout(() => reject(new Error(`Child readiness timed out: ${stderr}`)), timeoutMs);
        })
      ]);
    } finally {
      clearTimeout(timer);
      child.stdout.off('data', onData);
    }
  }
  return { child, completion, wait, stop, waitForOutput };
}

export async function runManagedProcess(command, args, options = {}, timeoutMs = 45000, active = new Set()) {
  const process = startManagedProcess(command, args, options);
  active.add(process);
  try {
    const result = await process.wait(timeoutMs);
    if (!result) {
      const stopped = await process.stop();
      throw new Error(`Child exceeded ${timeoutMs}ms: ${stopped.stderr}`);
    }
    if (result.error) throw result.error;
    return result;
  } finally {
    await process.stop();
    active.delete(process);
  }
}

export async function startPreviewServer(script, options = {}) {
  const server = startManagedProcess(process.execPath, [script, '--dev'], {
    ...options,
    env: { ...process.env, ...options.env, PORT: '0', HOST: '127.0.0.1' }
  });
  try {
    const match = await server.waitForOutput(/Serving dist at http:\/\/127\.0\.0\.1:(\d+) /);
    const port = Number(match[1]);
    if (!(port > 0 && port <= 65535)) throw new Error('Server did not report its bound port');
    return { ...server, origin: `http://127.0.0.1:${port}` };
  } catch (error) {
    await server.stop();
    throw error;
  }
}

// A single request deadline covers headers and subsequent body consumption.
export function fetchWithDeadline(url, options = {}) {
  return fetch(url, { ...options, signal: AbortSignal.timeout(5000) });
}
''')
put('apps/publisher/test-support/build-workspace.js',r'''import assert from 'node:assert/strict';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { runManagedProcess } from '../scripts/lib/process-lifecycle.js';

export function createBuildWorkspace(packageRoot) {
  const parent = path.join(packageRoot, '.cache');
  fs.mkdirSync(parent, { recursive: true });
  // Inside the package for generated ESM/dependency resolution, but every write
  // (including build-tenants' internal dist and cache) is owned by this run.
  const root = fs.mkdtempSync(path.join(parent, 'test-build-'));
  const active = new Set();
  async function initialize() {
    await fsp.mkdir(path.join(root, 'tenants'), { recursive: true });
    await Promise.all(['tenant-alpha', 'tenant-beta'].map((id) => fsp.cp(
      path.join(packageRoot, 'tenants', id), path.join(root, 'tenants', id), { recursive: true }
    )));
    await fsp.mkdir(path.join(root, 'examples'), { recursive: true });
    await fsp.cp(path.join(packageRoot, 'examples', 'hybrid-react'), path.join(root, 'examples', 'hybrid-react'), { recursive: true });
  }
  async function stopChildren() {
    const outcomes = await Promise.allSettled([...active].map((child) => child.stop()));
    const failure = outcomes.find((result) => result.status === 'rejected');
    if (failure) throw failure.reason;
  }
  async function run(args = [], env = {}, expectedCode = 0) {
    const result = await runManagedProcess(process.execPath, [path.join(packageRoot, 'scripts', 'build-tenants.js'), ...args], {
      cwd: root,
      env: { ...process.env, NODE_ENV: 'development', GIT_CACHE_DIR: path.join(root, '.cache', 'git'), ...env }
    }, 45000, active);
    assert.equal(result.signal, null, `Build terminated by ${result.signal}: ${result.stderr}`);
    assert.equal(result.code, expectedCode, `Unexpected build exit (${result.code}):\n${result.stderr}\n${result.stdout}`);
    return result;
  }
  async function runRegistry(tenants, args = [], env = {}, expectedCode = 0) {
    const registryPath = path.join(root, `registry-${randomUUID()}.json`);
    try {
      await fsp.writeFile(registryPath, JSON.stringify({
        defaults: { source: { type: 'local', path: './tenants' }, target: { type: 'local', path: './dist' } },
        tenants
      }));
      return await run(['-r', registryPath, ...args], env, expectedCode);
    } finally { await fsp.rm(registryPath, { force: true }); }
  }
  async function dispose() {
    await stopChildren();
    await fsp.rm(root, { recursive: true, force: true });
  }
  return { root, initialize, run, runRegistry, stopChildren, dispose };
}
''')
# Product fixes.
p='apps/publisher/scripts/build-tenants.js';s=read(p)
s=replace(s,"  const [username, password] = credentials.split(':', 2);", "  const separator = credentials.indexOf(':');\n  const username = separator < 0 ? '' : credentials.slice(0, separator);\n  const password = separator < 0 ? undefined : credentials.slice(separator + 1);")
s=replace(s,'function resolveTheme(themeSpec, overrides = {}) {','export function resolveTheme(themeSpec, overrides = {}) {')
put(p,s)
p='apps/publisher/scripts/serve.js';s=read(p);s=replace(s,'  console.log(`Serving dist at http://${host}:${port} ${DEV', '  const boundPort = server.address().port;\n  console.log(`Serving dist at http://${host}:${boundPort} ${DEV');put(p,s)
p='apps/publisher/scripts/lib/rich-content-adapters.js';s=read(p)
s=replace(s,'      results.push(missingAdapterResult(node, options, failurePolicy));','      results.push(enforceFailurePolicy(missingAdapterResult(node, options, failurePolicy), failurePolicy));')
s=replace(s,'      return resultForDiagnostics(node, adapter, validationDiagnostics, context, started);','      return enforceFailurePolicy(resultForDiagnostics(node, adapter, validationDiagnostics, context, started), context.failurePolicy);')
s=replace(s,'        return hit;','        return enforceFailurePolicy(hit, context.failurePolicy);')
s=replace(s,'    normalized.rendererMetadata.durationMs = Date.now() - started;','    enforceFailurePolicy(normalized, context.failurePolicy);\n    normalized.rendererMetadata.durationMs = Date.now() - started;')
s=replace(s,'    const diagnostics = normalizeDiagnostics(adapter.diagnose(error, node, rendererContext), adapter, node, context);','    const diagnostics = normalizeDiagnostics(error?.diagnostics || adapter.diagnose(error, node, rendererContext), adapter, node, context);')
s=replace(s,'      strictError.diagnostics = fallback.diagnostics;','      strictError.code = fallback.diagnostics[0]?.code || \'RTC_RENDER_FAILED\';\n      strictError.diagnostics = fallback.diagnostics;')
s=s.replace('function resultForDiagnostics(node, adapter, diagnostics, context, started) {',r'''function enforceFailurePolicy(result, policy) {
  const failure = result.diagnostics.find((diagnostic) => diagnostic.severity === 'error');
  if (policy === 'strict' && failure) {
    const error = new Error(failure.message || 'Renderer validation failed');
    error.code = failure.code;
    error.diagnostics = result.diagnostics;
    throw error;
  }
  return result;
}

function resultForDiagnostics(node, adapter, diagnostics, context, started) {''');put(p,s)
# Credential oracle + edge-case preservation regression.
p='apps/publisher/__tests__/scripts/build-tenants-git-source.test.js';s=read(p)
s=replace(s,'    // split(\':\', 2) → username "alice", password "p@ss/wo" (first colon splits);\n    // the password is percent-encoded so the URL stays well-formed.', '    // Only the first colon separates username/password; later colons are data.')
s=replace(s,'https://alice:p%40ss%2Fwo@git.example.com/org/repo.git','https://alice:p%40ss%2Fwo%3Ard@git.example.com/org/repo.git')
s=s.replace("  test('leaves an SSH/git URL untouched'", "  test('preserves consecutive and trailing password colons', () => {\n    process.env.GIT_CREDENTIALS = 'alice::part:';\n    expect(withGitCredentials('https://git.example.com/repo.git'))\n      .toBe('https://alice:%3Apart%3A@git.example.com/repo.git');\n  });\n\n  test('leaves an SSH/git URL untouched'");put(p,s)
# Private build CWD, fixture and registry, bounded tracked children and central exit oracle.
for name in ['build-tenants','build-tenants-nested']:
 p=f'apps/publisher/__tests__/scripts/{name}.test.js';s=read(p)
 s=s.replace("import { spawn } from 'child_process';", "import { createBuildWorkspace } from '../../test-support/build-workspace.js';")
 start=s.index('const BUILD_TENANTS_SCRIPT = ');end=s.index('// Helper to create',start)
 s=s[:start]+'''const buildWorkspace = createBuildWorkspace(PUBLISHER_ROOT);
const TEST_ROOT = buildWorkspace.root;
beforeAll(() => buildWorkspace.initialize());
afterEach(() => buildWorkspace.stopChildren());
afterAll(() => buildWorkspace.dispose());
const runBuildTenants = buildWorkspace.run;
const runBuildTenantsWithRegistry = buildWorkspace.runRegistry;

'''+s[end:]
 # Preserve package-root source reads; redirect every fixture/output reference.
 s=s.replace("PUBLISHER_ROOT, 'tenants'", "TEST_ROOT, 'tenants'").replace("PUBLISHER_ROOT, 'dist'", "TEST_ROOT, 'dist'")
 if name=='build-tenants-nested':
  needle="      const result = await runBuildTenantsWithRegistry([{ id: TEST_ID }]);\n      expect(result.code).not.toBe(0);"
  s=replace(s,needle,"      const result = await runBuildTenantsWithRegistry([{ id: TEST_ID }], [], {}, 1);\n      expect(result.code).toBe(1);")
 else:
  needle="      const result = await runBuildTenantsWithRegistry([{ id: TEST_TENANT_ID }]);\n      expect(result.code).toBe(1);"
  s=replace(s,needle,"      const result = await runBuildTenantsWithRegistry([{ id: TEST_TENANT_ID }], [], {}, 1);\n      expect(result.code).toBe(1);",2)
  start=s.index("      const result = await runBuildTenantsWithRegistry([{ id: TEST_TENANT_ID }]);\n      // The 2d tier")
  end=s.index('      if (sigmaInstalled) {',start)
  fragment=s[start:end];fragment=fragment.replace("      const result = await runBuildTenantsWithRegistry([{ id: TEST_TENANT_ID }]);\n",'')
  s=s[:start]+fragment+"      const result = await runBuildTenantsWithRegistry([{ id: TEST_TENANT_ID }], [], {}, sigmaInstalled ? 0 : 1);\n"+s[end:]
  # Run-owned source copies are exercised concurrently with same tenant IDs.
  anchor="    test('creates separate dist directories for each tenant', async () => {"
  extra='''    test('simultaneous workspaces keep the same tenant id and registry isolated', async () => {
      const other = createBuildWorkspace(PUBLISHER_ROOT);
      try {
        await other.initialize();
        const [first, second] = await Promise.all([
          runBuildTenantsWithRegistry([{ id: 'tenant-alpha', config: { title: 'First owned build' } }]),
          other.runRegistry([{ id: 'tenant-alpha', config: { title: 'Second owned build' } }])
        ]);
        expect(first.code).toBe(0);
        expect(second.code).toBe(0);
        expect(other.root).not.toBe(TEST_ROOT);
        const ownHtml = await fsp.readFile(path.join(TEST_ROOT, 'dist', 'tenant-alpha', 'index.html'), 'utf8');
        const otherHtml = await fsp.readFile(path.join(other.root, 'dist', 'tenant-alpha', 'index.html'), 'utf8');
        expect(ownHtml).toContain('First owned build');
        expect(ownHtml).not.toContain('Second owned build');
        expect(otherHtml).toContain('Second owned build');
        expect(otherHtml).not.toContain('First owned build');
      } finally { await other.dispose(); }
    });

    test('rejects a nonzero build centrally before callers inspect partial output', async () => {
      await expect(runBuildTenantsWithRegistry([{ id: 'missing-owned-tenant' }]))
        .rejects.toThrow(/Unexpected build exit/);
    });

'''
  s=s.replace(anchor,extra+anchor)
 put(p,s)
# Strict validation regression exercises failure before rendering and all policy paths.
p='apps/publisher/__tests__/scripts/rich-content-core.test.js';s=read(p)
anchor="  test('serves warm adapter results without another renderer invocation', async () => {"
extra=r'''  test.each(['strict', 'warn', 'off'])('invalid nodes honor %s policy before rendering', async (failurePolicy) => {
    let invocations = 0;
    const registry = createRendererRegistry();
    registry.register(defineRendererAdapter({
      id: 'invalid',
      validate() { return [{ code: 'MOCK_BAD', severity: 'error', message: 'Bad mock node' }]; },
      async render() { invocations++; return { html: '<p>must not render</p>' }; }
    }));
    const pending = renderRichContentNodes([{ renderer: 'invalid', body: '<bad>' }], { registry, failurePolicy });
    if (failurePolicy === 'strict') {
      await expect(pending).rejects.toMatchObject({
        code: 'MOCK_BAD', diagnostics: [expect.objectContaining({ code: 'MOCK_BAD', severity: 'error' })]
      });
    } else {
      const [result] = await pending;
      expect(result.html).toBe(failurePolicy === 'off' ? '' : '<pre class="rich-content-fallback"><code>&lt;bad&gt;</code></pre>');
      expect(result.diagnostics).toEqual([expect.objectContaining({
        code: 'MOCK_BAD', severity: failurePolicy === 'warn' ? 'warning' : 'error'
      })]);
    }
    expect(invocations).toBe(0);
  });

  test('strict policy rejects cached error diagnostics from a permissive render', async () => {
    const registry = createRendererRegistry();
    const cache = new RendererCache({ rootDir: await createCacheDirectory('pagenary-policy-cache-') });
    let invocations = 0;
    registry.register(defineRendererAdapter({
      id: 'partial-cache',
      async render() {
        invocations++;
        return { html: '<p>partial</p>', diagnostics: [{ code: 'CACHED_ERROR', severity: 'error', message: 'Incomplete render' }] };
      }
    }));
    const nodes = [{ renderer: 'partial-cache', body: 'input' }];
    const options = { registry, cache, tenantId: 'docs', pageId: 'policy' };
    const [permissive] = await renderRichContentNodes(nodes, { ...options, failurePolicy: 'warn' });
    expect(permissive.rendererMetadata.cacheStatus).toBe('miss');
    await expect(renderRichContentNodes(nodes, { ...options, failurePolicy: 'strict' }))
      .rejects.toMatchObject({ code: 'CACHED_ERROR' });
    expect(invocations).toBe(1);
  });

  test('strict policy rejects missing adapters and error-bearing render results', async () => {
    const registry = createRendererRegistry();
    await expect(renderRichContentNodes([{ renderer: 'missing', body: 'input' }], { registry, failurePolicy: 'strict' }))
      .rejects.toMatchObject({ code: 'RTC_RENDERER_UNAVAILABLE' });
    registry.register(defineRendererAdapter({
      id: 'partial',
      async render() { return { html: '<p>partial</p>', diagnostics: [{ code: 'PARTIAL_FAILED', severity: 'error', message: 'Partial render failed' }] }; }
    }));
    await expect(renderRichContentNodes([{ renderer: 'partial', body: 'input' }], { registry, failurePolicy: 'strict' }))
      .rejects.toMatchObject({ code: 'PARTIAL_FAILED' });
  });

'''
s=s.replace(anchor,extra+anchor);put(p,s)
# LaTeX root ownership is registered before any setup operation can fail.
p='apps/publisher/__tests__/scripts/latex-page.test.js';s=read(p)
s=s.replace("import os from 'node:os';", "import os from 'node:os';\nimport { createHash } from 'node:crypto';")
anchor="const root = path.resolve('/workspace/content');"
extra='''const ownedTempDirectories = [];
async function createTempDirectory(prefix) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), prefix));
  ownedTempDirectories.push(dir);
  return dir;
}
afterEach(async () => {
  await Promise.all(ownedTempDirectories.splice(0).map((dir) => fs.rm(dir, { recursive: true, force: true })));
});

'''
s=s.replace(anchor,extra+anchor)
s,n=re.subn(r"await fs.mkdtemp\(path.join\(os.tmpdir\(\), ('pagenary-[^']+')\)\)",r'await createTempDirectory(\1)',s);assert n==8,n
needle="      expect(result.assets[0].bytes.toString()).not.toMatch(/script|onload/i);"
s=replace(s,needle,'''      const svg = result.assets[0].bytes.toString();
      expect(svg).toMatch(/^<svg\\b/);
      expect(svg).toContain('<text>Chart</text>');
      expect(svg).not.toMatch(/script|onload/i);
      const digest = createHash('sha256').update(result.assets[0].bytes).digest('hex').slice(0, 24);
      expect(result.assets[0].path).toBe(`assets/rich-content/latex/${digest}.svg`);''');put(p,s)
# Both preview suites use a PORT=0 child-owned readiness signal and bounded HTTP.
p='apps/publisher/__tests__/scripts/markdown-server.test.js';s=read(p)
s=s.replace("import { spawn } from 'node:child_process';\n", "import { startPreviewServer, fetchWithDeadline } from '../../scripts/lib/process-lifecycle.js';\n").replace("import http from 'node:http';\n",'')
a=s.index('function waitFor(');b=s.index("describe('preview server",a);s=s[:a]+s[b:]
s=s.replace('  let child;','  let server;')
a=s.index('    const port = 20000');b=s.index('  it(\'serves HTML',a)
s=s[:a]+'''    server = await startPreviewServer(SERVER, {
      cwd,
      env: { DEFAULT_TENANT: 'test', PAGENARY_SERVE_MOUNT: '/docs' }
    });
    origin = server.origin;
  });

  afterAll(async () => {
    try { await server?.stop(); }
    finally { if (cwd) await fsp.rm(cwd, { recursive: true, force: true }); }
  });

'''+s[b:]
s=s.replace('await fetch(', 'await fetchWithDeadline(');put(p,s)
p='apps/publisher/__tests__/scripts/cli.test.js';s=read(p)
s=s.replace("import { spawn, spawnSync } from 'node:child_process';", "import { spawnSync } from 'node:child_process';\nimport { startPreviewServer, startManagedProcess, runManagedProcess, fetchWithDeadline } from '../../scripts/lib/process-lifecycle.js';")
s=s.replace("    encoding: 'utf8',\n    cwd:","    encoding: 'utf8',\n    timeout: 30000,\n    cwd:")
s=s.replace("  return { code: res.status,", "  if (res.error) throw res.error;\n  return { code: res.status,")
a=s.index('async function waitForHttp(');b=s.index("describe('pagenary CLI dispatch'",a);s=s[:a]+s[b:]
a=s.index("    const tenantDir = path.join(tmp, 'dist', 'fortemi-docs');");b=s.index("\n  });\n});",a)
s=s[:a]+'''    let server;
    try {
      const tenantDir = path.join(tmp, 'dist', 'fortemi-docs');
      await fsp.mkdir(tenantDir, { recursive: true });
      await fsp.writeFile(path.join(tenantDir, 'index.html'), '<!doctype html><title>Fortemi</title>', 'utf8');
      await fsp.writeFile(path.join(tenantDir, 'styles.css'), 'body { color: black; }', 'utf8');
      server = await startPreviewServer(SERVE_SCRIPT, {
        cwd: tmp, env: { PAGENARY_SERVE_MOUNT: '/server' }
      });
      const rootRes = await fetchWithDeadline(`${server.origin}/server/`);
      expect(rootRes.status).toBe(200);
      expect(await rootRes.text()).toContain('Fortemi');
      const cssRes = await fetchWithDeadline(`${server.origin}/server/styles.css`);
      expect(cssRes.status).toBe(200);
      expect(await cssRes.text()).toContain('color: black');
    } finally {
      try { await server?.stop(); }
      finally { await fsp.rm(tmp, { recursive: true, force: true }); }
    }'''+s[b:]
s+='''

describe('owned child lifecycle failures', () => {
  test('startup failure rejects readiness and cleanup observes an already exited child', async () => {
    const child = startManagedProcess(process.execPath, ['-e', 'process.stderr.write("startup fixture"); process.exit(7)']);
    try {
      await expect(child.waitForOutput(/never-ready/)).rejects.toThrow(/Child exited before readiness/);
      const completed = await child.completion;
      expect(completed.code).toBe(7);
      expect(await child.stop()).toEqual(completed);
    } finally { await child.stop(); }
  });

  test('a stalled process is terminated and reported as a timeout', async () => {
    await expect(runManagedProcess(process.execPath, ['-e', 'setInterval(() => {}, 1000)'], {}, 100))
      .rejects.toThrow(/Child exceeded 100ms/);
  });
});
''';put(p,s)
# Validation and review artifacts only; no proposed source file is applied.
for p,s in edits.items():
 check=subprocess.run(['node','--input-type=module','--check'],input=s,text=True,capture_output=True)
 assert check.returncode==0,(p,check.stderr)
proposal={'purpose':'Resolve all nine open publisher oracle/lifecycle findings with private build CWDs and explicit expected exits, bounded owned processes, credential preservation, strict diagnostics policy and substantive regression oracles. Source changes remain proposed until parent guarded application.','edits':[{'path':p,'content':s} for p,s in edits.items()]}
(root/'.aiwg/testing/edits-publisher-03.json').write_text(json.dumps(proposal,indent=2)+'\n')
diff=''.join(''.join(difflib.unified_diff((root/p).read_text().splitlines(True) if (root/p).exists() else [],s.splitlines(True),fromfile=p,tofile=p)) for p,s in edits.items())
(root/'.aiwg/testing/edits-publisher-03.diff').write_text(diff)
print('Prepared and syntax-checked',len(edits),'files; diff lines',len(diff.splitlines()))
