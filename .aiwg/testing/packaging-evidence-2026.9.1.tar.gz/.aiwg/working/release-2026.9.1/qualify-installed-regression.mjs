import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { runManagedProcess } from '../../../apps/publisher/scripts/lib/process-lifecycle.js';

const root = process.cwd();
const evidence = path.join(root, '.aiwg/working/release-2026.9.1');
const packageRoot = path.join(root, 'apps/publisher');
const isolated = await fs.mkdtemp(path.join(os.tmpdir(), 'pagenary-package-control-'));
const target = path.join(isolated, 'apps/publisher');
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const sharedPath = path.join(packageRoot, 'scripts/prepare-package.js');
const original = await fs.readFile(sharedPath);
const report = { kind: 'IsolatedInstalledArtifactControl', sharedSourceBeforeSha256: digest(original), runs: [] };
try {
  await fs.cp(packageRoot, target, { recursive: true, dereference: true, filter(source) {
    return !path.relative(packageRoot, source).split(path.sep).some(part => ['node_modules','dist','site','.cache','.playwright-mcp','.git'].includes(part));
  } });
  await fs.mkdir(path.join(isolated, 'apps/authoring-contract'), { recursive: true });
  await fs.copyFile(path.join(root, 'apps/authoring-contract/index.cjs'), path.join(isolated, 'apps/authoring-contract/index.cjs'));
  await fs.symlink(path.join(root, 'node_modules'), path.join(isolated, 'node_modules'), 'junction');
  const changed = path.join(target, 'scripts/prepare-package.js');
  const mutant = "import { rm } from 'node:fs/promises';\nawait rm(new URL('./lib/authoring-contract.cjs', import.meta.url), { force: true });\n";
  report.mutation = { path: 'apps/publisher/scripts/prepare-package.js', purpose: 'Omit bundled contract from actual npm prepack artifact while canonical workspace source remains present.', beforeSha256: digest(original), afterSha256: digest(mutant) };
  for (const stage of ['mutant','restored']) {
    await fs.writeFile(changed, stage === 'mutant' ? mutant : original);
    const result = await runManagedProcess(process.execPath, ['--experimental-vm-modules', path.join(root,'node_modules/jest/bin/jest.js'), '--config',path.join(target,'jest.config.js'),'--runInBand','--runTestsByPath',path.join(target,'__tests__/scripts/cli.test.js'),'--testNamePattern=real prepack bundles'], {cwd:target},300000);
    const log=path.join(evidence,`installed-regression-control-${stage}.log`);
    await fs.writeFile(log,result.stdout+result.stderr);
    report.runs.push({stage,exitCode:result.code,signal:result.signal,log,logSha256:digest(result.stdout+result.stderr)});
    if (stage === 'mutant') {
      if (result.code !== 1 || !result.stderr.includes('metadata.files.some') || !result.stderr.includes('Received: false')) throw new Error('Mutant did not fail required packed-contract membership assertion');
    } else if (result.code !== 0) throw new Error('Restored isolated artifact regression did not pass');
  }
  report.sharedSourceAfterSha256=digest(await fs.readFile(sharedPath));
  report.sharedSourceUnchanged=report.sharedSourceBeforeSha256===report.sharedSourceAfterSha256;
  if (!report.sharedSourceUnchanged) throw new Error('Shared prepack source changed unexpectedly');
  report.status='killed-and-restored';
} catch(error) { report.status='failed';report.error=error.stack;process.exitCode=1; }
finally {
  await fs.rm(isolated,{recursive:true,force:true});
  report.isolatedTemporaryRemoved=true;
  await fs.writeFile(path.join(evidence,'installed-regression-control.json'),JSON.stringify(report,null,2)+'\n');
}
