import sys,tempfile,tarfile,json,subprocess,os,shutil
from pathlib import Path
root=Path.cwd();archive=Path(sys.argv[1]).resolve();out=root/'.aiwg/working/release-2026.9.1'
with tempfile.TemporaryDirectory(prefix='pagenary-published-smoke-') as temporary:
 base=Path(temporary)
 with tarfile.open(archive) as t:t.extractall(base,filter='data')
 package=base/'package';metadata=json.loads((package/'package.json').read_text());assert metadata['version']=='2026.9.1'
 assert (package/'scripts/lib/authoring-contract.cjs').read_bytes()==(root/'apps/authoring-contract/index.cjs').read_bytes()
 deps={**metadata.get('dependencies',{}),**metadata.get('optionalDependencies',{})}
 for name in deps:
  source=root/'node_modules'/name
  if not source.exists() and name in metadata.get('optionalDependencies',{}):continue
  target=package/'node_modules'/name;target.parent.mkdir(parents=True,exist_ok=True);target.symlink_to(source.resolve(),target_is_directory=True)
 assert not (package/'node_modules/@pagenary').exists()
 consumer=base/'consumer';(consumer/'content').mkdir(parents=True)
 (consumer/'content/welcome.md').write_text('# Published package\n\nRelease verification sentinel.\n')
 (consumer/'tenants.json').write_text(json.dumps({'tenants':[{'id':'installed','source':{'type':'local','path':'./content'},'config':{'title':'Published package','docsMap':False}}]}))
 env=os.environ.copy()
 for key in ['NODE_OPTIONS','NODE_PATH','TENANT_REGISTRY']:env.pop(key,None)
 p=subprocess.run(['node',str(package/'bin/pagenary.mjs'),'build','installed','--registry','tenants.json'],cwd=consumer,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (out/(archive.name+'.installed.log')).write_text(p.stdout)
 assert p.returncode==0,p.stdout[-4000:]
 assert 'Release verification sentinel.' in (consumer/'dist/installed/sections/welcome.js').read_text()
 assert 'Published package' in (consumer/'dist/installed/index.html').read_text()
 report={'archive':str(archive),'version':metadata['version'],'detached':True,'contractMatchesCanonical':True,'consumerBuildExitCode':p.returncode,'outputVerified':True}
 (out/(archive.name+'.installed.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
