import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import yaml from 'js-yaml';
const version='2026.9.1';
const repo='https://git.integrolabs.net';
const config=yaml.load(fs.readFileSync(path.join(os.homedir(),'.config/tea/config.yml'),'utf8'));
const login=config.logins.find(x=>x.url.replace(/\/$/,'')===repo && x.token);
if(!login)throw Error('No configured read credential for canonical forge');
async function get(url){
 const headers=new URL(url).origin===repo?{Authorization:`token ${login.token}`} : {};
 const response=await fetch(url,{headers,signal:AbortSignal.timeout(60000)});
 if(!response.ok)throw Error(`HTTP ${response.status} for ${new URL(url).pathname}`);
 return response;
}
const release=await (await get(`${repo}/api/v1/repos/roctinam/pagenary/releases/tags/v${version}`)).json();
const out=path.resolve('.aiwg/working/release-2026.9.1/gitea-assets');fs.mkdirSync(out,{recursive:true});
const expected=[`pagenary-publisher-${version}.tgz`,`pagenary-site-${version}.tgz`,'checksums.txt'];
for(const name of expected){
 const asset=release.assets.find(x=>x.name===name);if(!asset)throw Error(`Missing asset ${name}`);
 const bytes=Buffer.from(await (await get(asset.browser_download_url)).arrayBuffer());
 if(bytes.length!==asset.size)throw Error(`Size mismatch ${name}`);
 fs.writeFileSync(path.join(out,name),bytes);
}
const lines=fs.readFileSync(path.join(out,'checksums.txt'),'utf8').trim().split(/\r?\n/);const checked=[];
for(const name of expected.filter(x=>x.endsWith('.tgz'))){
 const row=lines.map(x=>x.trim().split(/\s+/)).find(x=>x[1]?.replace(/^\*/,'')===name);if(!row)throw Error(`Missing checksum ${name}`);
 const actual=crypto.createHash('sha256').update(fs.readFileSync(path.join(out,name))).digest('hex');
 if(actual!==row[0])throw Error(`Checksum mismatch ${name}`);checked.push({name,sha256:actual});
}
const report={tag:`v${version}`,releaseUrl:release.html_url,assets:checked,status:'passed'};
fs.writeFileSync('.aiwg/working/release-2026.9.1/gitea-publication.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
