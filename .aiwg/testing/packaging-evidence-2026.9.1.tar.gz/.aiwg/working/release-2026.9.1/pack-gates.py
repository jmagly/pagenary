import subprocess,json
from pathlib import Path
out=Path('.aiwg/working/release-2026.9.1');result=[]
for base in ['blog-client','embed','publisher']:
 p=subprocess.run(['npm','pack','--dry-run','--json'],cwd='apps/'+base,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (out/('pack-'+base+'.log')).write_text(p.stderr)
 assert p.returncode==0,(base,p.returncode,p.stderr[-2000:])
 (out/('pack-'+base+'.json')).write_text(p.stdout)
 d=json.loads(p.stdout)[0];files=[x['path'] for x in d['files']];top=sorted(set(x.split('/')[0] for x in files))
 allow=Path('ci/expected-tarball-top-level'+('' if base=='publisher' else '.'+base)+'.txt')
 allowed={x.strip() for x in allow.read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')}
 assert set(top)<=allowed,(base,set(top)-allowed)
 assert not any('.aiwg' in x.split('/') for x in files)
 assert d['version']=='2026.9.1'
 if base=='publisher':assert 'scripts/lib/authoring-contract.cjs' in files
 result.append({'package':d['name'],'version':d['version'],'fileCount':len(files),'topLevel':top,'allowed':True,'aiwgExcluded':True})
(out/'package-gates.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
