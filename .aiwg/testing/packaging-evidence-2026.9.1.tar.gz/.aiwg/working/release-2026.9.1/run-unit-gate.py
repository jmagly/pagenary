import subprocess,json,os,time
from pathlib import Path
out=Path('.aiwg/working/release-2026.9.1')
env=os.environ.copy()
env['PLAYWRIGHT_MODULE']='/tmp/pagenary-playwright/node_modules/playwright/index.mjs'
env['PLAYWRIGHT_BROWSERS_PATH']='/home/roctinam/.codex/roles-runtime/full/.cache/ms-playwright'
started=time.time()
with (out/'publisher-unit.log').open('w') as log:
 r=subprocess.run(['npm','run','test:publisher'],env=env,stdout=log,stderr=subprocess.STDOUT)
report={'command':'npm run test:publisher','exitCode':r.returncode,'seconds':time.time()-started}
(out/'publisher-unit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
raise SystemExit(r.returncode)
