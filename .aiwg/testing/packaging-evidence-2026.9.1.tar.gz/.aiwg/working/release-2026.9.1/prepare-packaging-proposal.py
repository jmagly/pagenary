from pathlib import Path
import json,subprocess,difflib
edits=[]
def put(path,content):edits.append({'path':path,'content':content})
put('apps/publisher/scripts/lib/authoring-contract.js', '''import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
let contractPath;
try {
  // Development and source controls must observe the canonical shared module.
  contractPath = require.resolve('../../../authoring-contract/index.cjs');
} catch (error) {
  if (error.code !== 'MODULE_NOT_FOUND') throw error;
  contractPath = require.resolve('./authoring-contract.cjs');
}
// Load outside the resolution catch: a broken canonical module must not silently
// fall back to a previously bundled copy.
export default require(contractPath);
''')
put('apps/publisher/scripts/prepare-package.js', '''#!/usr/bin/env node
import { copyFile } from 'node:fs/promises';

// prepack runs in the source workspace, before scripts importing this contract.
// The generated copy is shipped under scripts/ but never replaces the canonical
// workspace module used by development builds and source-bound tests.
await copyFile(
  new URL('../../authoring-contract/index.cjs', import.meta.url),
  new URL('./lib/authoring-contract.cjs', import.meta.url)
);
''')
for path,old,new in [
 ('apps/publisher/scripts/build-tenants.js',"from '../../authoring-contract/index.cjs'","from './lib/authoring-contract.js'"),
 ('apps/publisher/scripts/check-rich-content-traceability.mjs',"from '../../authoring-contract/index.cjs'","from './lib/authoring-contract.js'"),
 ('apps/publisher/scripts/lib/mermaid-build-adapter.js',"from '../../../authoring-contract/index.cjs'","from './authoring-contract.js'"),
 ('apps/publisher/scripts/lib/plantuml-renderer.js',"from '../../../authoring-contract/index.cjs'","from './authoring-contract.js'")]:
 s=Path(path).read_text();assert s.count(old)==1;put(path,s.replace(old,new))
p='apps/publisher/package.json';s=Path(p).read_text();old='"prepack": "node scripts/build-tenants.js pagenary >&2 && node scripts/build-site.js >&2"';new='"prepack": "node scripts/prepare-package.js && node scripts/build-tenants.js pagenary >&2 && node scripts/build-site.js >&2"';assert old in s;put(p,s.replace(old,new))
p='.gitignore';put(p,Path(p).read_text()+'\n# Generated canonical authoring contract, shipped by publisher prepack\n/apps/publisher/scripts/lib/authoring-contract.cjs\n')
p='apps/publisher/__tests__/scripts/cli.test.js';s=Path(p).read_text();s+='''

describe('published publisher package', () => {
  test('real prepack bundles the shared contract and detached package builds a tenant', async () => {
    const temporary = await fsp.mkdtemp(path.join(os.tmpdir(), 'pagenary-installed-package-'));
    const stage = path.join(temporary, 'workspace', 'apps', 'publisher');
    const detached = path.join(temporary, 'installed');
    const dependencies = path.resolve(PKG_ROOT, '../..', 'node_modules');
    const childEnv = { ...process.env, NODE_ENV: 'development' };
    delete childEnv.NODE_OPTIONS;
    delete childEnv.NODE_PATH;
    delete childEnv.TENANT_REGISTRY;
    const run = async (command, args, cwd, timeout = 180000) => {
      const result = await runManagedProcess(command, args, { cwd, env: childEnv }, timeout);
      expect({ code: result.code, signal: result.signal, stderr: result.stderr })
        .toEqual({ code: 0, signal: null, stderr: expect.any(String) });
      return result;
    };
    try {
      // Pack in a private source workspace: prepack's site/dist cannot race other
      // publisher tests. Materialize documentation symlinks while copying.
      await fsp.cp(PKG_ROOT, stage, { recursive: true, dereference: true, filter(source) {
        const parts = path.relative(PKG_ROOT, source).split(path.sep);
        return !parts.some(part => ['node_modules', 'dist', 'site', '.cache', '.playwright-mcp', '.git'].includes(part));
      } });
      const canonical = path.join(temporary, 'workspace', 'apps', 'authoring-contract', 'index.cjs');
      await fsp.mkdir(path.dirname(canonical), { recursive: true });
      await fsp.copyFile(path.resolve(PKG_ROOT, '../authoring-contract/index.cjs'), canonical);
      await fsp.symlink(dependencies, path.join(stage, 'node_modules'), 'junction');
      const bundled = path.join(stage, 'scripts/lib/authoring-contract.cjs');
      await fsp.writeFile(bundled, 'module.exports = { staleBundle: true };\\n');
      // A stale packed copy must not hide changes to the workspace contract.
      await run(process.execPath, ['--input-type=module', '-e', String.raw`
        import assert from 'node:assert/strict';
        import { createRequire } from 'node:module';
        import contract from './scripts/lib/authoring-contract.js';
        const require = createRequire(import.meta.url);
        assert.strictEqual(contract, require('../authoring-contract/index.cjs'));
        assert.equal(contract.staleBundle, undefined);
      `], stage);
      const packed = await run(process.platform === 'win32' ? 'npm.cmd' : 'npm',
        ['pack', '--json', '--pack-destination', temporary], stage);
      const [metadata] = JSON.parse(packed.stdout);
      expect(metadata.files.some(file => file.path === 'scripts/lib/authoring-contract.cjs')).toBe(true);
      expect(metadata.files.some(file => file.path === 'site/index.html')).toBe(true);
      await fsp.mkdir(detached);
      await run('tar', ['-xzf', path.join(temporary, metadata.filename), '-C', detached], temporary);
      const installed = path.join(detached, 'package');
      // External dependencies may resolve from the installed dependency tree;
      // publisher code and the authoring contract must come from this tarball.
      const installedMetadata = JSON.parse(await fsp.readFile(path.join(installed, 'package.json'), 'utf8'));
      for (const name of Object.keys({ ...installedMetadata.dependencies, ...installedMetadata.optionalDependencies })) {
        const dependency = path.join(dependencies, name);
        if (!fs.existsSync(dependency) && installedMetadata.optionalDependencies?.[name]) continue;
        const target = path.join(installed, 'node_modules', name);
        await fsp.mkdir(path.dirname(target), { recursive: true });
        await fsp.symlink(await fsp.realpath(dependency), target, 'junction');
      }
      expect(fs.existsSync(path.join(installed, 'node_modules', '@pagenary'))).toBe(false);
      expect(fs.existsSync(path.join(detached, 'authoring-contract'))).toBe(false);
      await run(process.execPath, ['--input-type=module', '-e', String.raw`
        import assert from 'node:assert/strict';
        import { createRequire } from 'node:module';
        import contract from './scripts/lib/authoring-contract.js';
        import { markdownToHtml } from './scripts/build-tenants.js';
        import { createPlantUmlAdapter } from './scripts/lib/plantuml-renderer.js';
        import './scripts/lib/mermaid-build-adapter.js';
        const require = createRequire(import.meta.url);
        assert.strictEqual(contract, require('./scripts/lib/authoring-contract.cjs'));
        const matches = contract.scanRichFences('\\x60\\x60\\x60puml title="Published"\\nAlice -> Bob\\n\\x60\\x60\\x60');
        assert.equal(matches.length, 1);
        assert.deepEqual(contract.parseRichFenceInfo(matches[0][1], matches[0][2]),
          { authored: 'puml', renderer: 'plantuml', title: 'Published' });
        assert.ok(markdownToHtml('# Installed contract').includes('Installed contract'));
        assert.equal(createPlantUmlAdapter().id, 'plantuml');
      `], installed);
      const project = path.join(temporary, 'consumer');
      await fsp.mkdir(path.join(project, 'content'), { recursive: true });
      await fsp.writeFile(path.join(project, 'content', 'welcome.md'), '# Detached package works\\n\\nPublished build sentinel.\\n');
      await fsp.writeFile(path.join(project, 'tenants.json'), JSON.stringify({ tenants: [{
        id: 'installed', source: { type: 'local', path: './content' }, config: { title: 'Detached package', docsMap: false }
      }] }));
      await run(process.execPath, [path.join(installed, 'bin/pagenary.mjs'), 'build', 'installed', '--registry', 'tenants.json'], project);
      const html = await fsp.readFile(path.join(project, 'dist/installed/index.html'), 'utf8');
      expect(html).toContain('Detached package');
      const markdown = await fsp.readFile(path.join(project, 'dist/installed/markdown/welcome.md'), 'utf8');
      expect(markdown).toContain('Published build sentinel.');
    } finally {
      await fsp.rm(temporary, { recursive: true, force: true });
    }
  }, 240000);
});
''';put(p,s)
# Parse all proposed JS without running it.
for e in edits:
 if e['path'].endswith(('.js','.mjs')):subprocess.run(['node','--input-type=module','--check'],input=e['content'],text=True,check=True)
out=Path('.aiwg/working/release-2026.9.1/edits-publisher-packaging-01.json');out.write_text(json.dumps({'purpose':'Bundle the canonical authoring contract for installed publisher use while preserving workspace-source controls; qualify real npm pack/prepack and detached tenant build. Package version unchanged.','edits':edits},indent=2)+'\n')
Path('.aiwg/working/release-2026.9.1/publisher-packaging-01.diff').write_text(''.join(''.join(difflib.unified_diff(Path(e['path']).read_text().splitlines(True) if Path(e['path']).exists() else [],e['content'].splitlines(True),fromfile=e['path'],tofile=e['path'])) for e in edits))
print(len(edits),'proposed files; JS syntax valid; no source applied')
